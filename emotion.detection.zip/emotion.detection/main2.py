import gradio as gr
import numpy as np
import cv2
from tensorflow.keras.models import load_model

# Load the model
model = load_model("saved_model")

# Load Haar Cascade for face detection
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Emotion labels (based on training order)
emotion_labels = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']

# Prediction function for static images
def detect_emotion(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

    for (x, y, w, h) in faces:
        face = gray[y:y+h, x:x+w]
        face = cv2.resize(face, (48, 48))
        face = face.astype("float32") / 255.0
        face = np.expand_dims(face, axis=0)
        face = np.expand_dims(face, axis=-1)

        prediction = model.predict(face)[0]
        print("Prediction probabilities:", prediction)  # Debug print
        max_index = np.argmax(prediction)
        emotion = emotion_labels[max_index]
        confidence = prediction[max_index]

        # Draw box and label on face with confidence score
        cv2.rectangle(image, (x, y), (x+w, y+h), (255, 0, 0), 2)
        label = f"{emotion} ({confidence*100:.1f}%)"
        cv2.putText(image, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

    return image

# Prediction function for real-time webcam video frames
def detect_emotion_realtime(frame):
    image = frame
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

    for (x, y, w, h) in faces:
        face = gray[y:y+h, x:x+w]
        face = cv2.resize(face, (48, 48))
        face = face.astype("float32") / 255.0
        face = np.expand_dims(face, axis=0)
        face = np.expand_dims(face, axis=-1)

        prediction = model.predict(face)[0]
        print("Prediction probabilities:", prediction)  # Debug print
        max_index = np.argmax(prediction)
        emotion = emotion_labels[max_index]
        confidence = prediction[max_index]

        # Draw box and label on face with confidence score
        cv2.rectangle(image, (x, y), (x+w, y+h), (255, 0, 0), 2)
        label = f"{emotion} ({confidence*100:.1f}%)"
        cv2.putText(image, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

    return image

# Gradio Interface with Tabs for two modes
with gr.Blocks() as demo:
    gr.Markdown("# EmotionVision – Facial Emotion Recognition")
    with gr.Tabs():
        with gr.TabItem("Upload Image"):
            image_input = gr.Image(type="numpy", label="Upload Image")
            image_output = gr.Image(label="Detected Emotion")
            image_input.change(detect_emotion, inputs=image_input, outputs=image_output)
        with gr.TabItem("Real-time Webcam"):
            webcam_input = gr.Image(label="Webcam Feed")
            webcam_output = gr.Image(label="Detected Emotion")
            webcam_input.change(detect_emotion_realtime, inputs=webcam_input, outputs=webcam_output)

demo.launch()
